---
company: "Apple"
role: "Software Engineer"
dateStart: "01/01/2020"
dateEnd: "11/27/2022"
---

Voluptatem est quaerat voluptas praesentium ipsa dolorem dignissimos nulla ratione distinctio quae maiores eligendi nostrum? Quibusdam, debitis voluptatum, lorem ipsum dolor. Sit amet consectetur adipisicing elit. Iure illo neque tempora.